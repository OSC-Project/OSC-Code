export { default } from '@ember-data/adapter/rest';
