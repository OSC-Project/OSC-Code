/**
  @module ember-data
*/
export { belongsTo, hasMany } from '@ember-data/model';
