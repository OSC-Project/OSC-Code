export { default } from '@ember-data/serializer/json-api';
