export { EmbeddedRecordsMixin as default } from '@ember-data/serializer/rest';
