import initializeStoreService from 'ember-data/initialize-store-service';

export default {
  name: 'ember-data',
  initialize: initializeStoreService,
};
