export { default } from '@ember-data/store';
