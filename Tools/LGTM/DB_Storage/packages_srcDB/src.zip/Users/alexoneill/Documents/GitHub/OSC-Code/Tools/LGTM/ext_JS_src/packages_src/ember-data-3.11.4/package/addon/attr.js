export { attr as default } from '@ember-data/model';
