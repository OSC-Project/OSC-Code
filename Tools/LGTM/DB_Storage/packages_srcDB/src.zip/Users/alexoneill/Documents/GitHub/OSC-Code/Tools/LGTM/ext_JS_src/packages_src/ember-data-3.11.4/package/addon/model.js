export { default } from '@ember-data/model';
