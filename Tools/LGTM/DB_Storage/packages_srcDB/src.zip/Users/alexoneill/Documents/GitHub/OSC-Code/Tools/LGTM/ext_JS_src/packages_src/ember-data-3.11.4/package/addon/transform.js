export { default } from '@ember-data/serializer/transform';
